# Kit graphique IA'm — Pro
## IA'm Graphic Kit — Pro

**Version 2026.1** — Lionel Le Berre, fondateur du label IA'm
INPI n° 5212301 — Classe 41 — CC BY-NC 4.0

---

## FR

### Contenu du kit

Ce kit est destiné aux signataires de la licence d'usage IA'm Pro.
Il contient l'ensemble des fichiers vectoriels et raster nécessaires
à l'intégration du label dans vos productions.

```
iam-kit-pro/
├── svg/
│   ├── couleur/             — or sur fond navy (version officielle)
│   ├── monochrome-noir/     — noir sur fond transparent
│   └── monochrome-blanc/    — blanc sur fond transparent
├── png/
│   ├── couleur/
│   │   ├── 120/  240/  480/  1024/    — exports en pixels
│   ├── monochrome-noir/
│   │   ├── 120/  240/  480/  1024/
│   └── monochrome-blanc/
│       ├── 120/  240/  480/  1024/
└── sources/                 — fichiers source (logo seul, formats originaux)
```

### Variantes incluses

Pour chaque variante de couleur (couleur, noir, blanc), vous disposez de :

- **iam-logo** — le logo seul (cercle ouvert + IA'm), sans label
- **iam-badge-assiste-fr** — badge complet niveau Assisté, français
- **iam-badge-assiste-en** — badge complet niveau Assisted, anglais
- **iam-badge-initie-fr** — badge complet niveau Initié, français
- **iam-badge-initie-en** — badge complet niveau Initiated, anglais
- **iam-badge-genere-fr** — badge complet niveau Généré, français
- **iam-badge-genere-en** — badge complet niveau Generated, anglais

### Quel format choisir ?

**SVG** (vectoriel) — usage recommandé. Redimensionnable sans perte,
adapté à l'impression haute qualité, au web, et à toute intégration
nécessitant une netteté parfaite à toutes les tailles.

**PNG** — pour les usages où SVG n'est pas accepté (certains réseaux
sociaux, certains éditeurs WYSIWYG, anciennes versions de logiciels).
Choisir la taille la plus proche de l'usage final, en privilégiant
toujours la version supérieure pour préserver la netteté.

| Usage | Format | Taille recommandée |
|---|---|---|
| Site web (logo header) | SVG | — |
| Article de presse en ligne | SVG ou PNG 240px | — |
| Réseau social (avatar, image) | PNG 480px | — |
| Présentation slide | SVG ou PNG 480px | — |
| Document A4 imprimé | SVG ou PNG 1024px | — |
| Affiche grand format | SVG uniquement | — |
| Favicon, icône applicative | PNG 120px | — |

### Quelle variante de couleur ?

**Couleur** (or sur navy) — version officielle, à privilégier dès
que possible. Fond navy intégré au visuel, donc utilisable sur
n'importe quel support.

**Monochrome noir** — fond transparent. À utiliser sur des fonds
clairs, blancs ou pastels. Idéal pour intégration dans des chartes
graphiques existantes claires.

**Monochrome blanc** — fond transparent. À utiliser exclusivement
sur des fonds sombres ou colorés saturés. Vérifier le contraste
avant publication.

### Règles d'usage

Voir le **Guide d'intégration éditoriale IA'm** fourni avec votre
licence, qui détaille :

- Le placement recommandé selon le type de production
- Les règles de proportions, espace de respiration, taille minimale
- Les usages interdits (déformation, intégration en logo composé,
  modification des couleurs hors variantes officielles)
- Les formulations textuelles d'accompagnement recommandées

### Support

Pour toute question d'intégration ou demande spécifique :
**liolb@iam-inside.eu**

---

## EN

### Kit contents

This kit is intended for signatories of the IA'm Pro license agreement.
It contains all vector and raster files needed to integrate the label
in your productions.

Structure as above. Variants available in colour (gold on navy),
black monochrome, and white monochrome. PNG exports in 120, 240,
480 and 1024 pixels.

### Variants included

For each colour variant, you have:

- **iam-logo** — the logo alone (open circle + IA'm), without label
- **iam-badge-assisted-en** — full Assisted badge, English
- **iam-badge-initiated-en** — full Initiated badge, English
- **iam-badge-generated-en** — full Generated badge, English
- (and French equivalents)

### Which format to use?

**SVG** (vector) — recommended use. Resizable without loss, suitable
for high-quality printing, web, and any integration requiring perfect
sharpness at all sizes.

**PNG** — for uses where SVG is not accepted. Choose the size closest
to your final use, always preferring the larger version to preserve
sharpness.

### Which colour variant?

**Colour** (gold on navy) — official version, to be preferred whenever
possible.

**Black monochrome** — transparent background. Use on light, white or
pastel backgrounds.

**White monochrome** — transparent background. Use exclusively on dark
or saturated backgrounds. Check contrast before publishing.

### Usage rules

See the **IA'm Editorial Integration Guide** provided with your
license, which details placement rules, proportions, breathing space,
minimum size, prohibited uses, and recommended accompanying text
phrasings.

### Support

For any integration question or specific request:
**liolb@iam-inside.eu**

---

## Licence / License

Ce kit est fourni dans le cadre de votre licence d'usage IA'm Pro.
Son contenu est protégé par le dépôt INPI n° 5212301 (classe 41) et
publié sous Creative Commons BY-NC 4.0. Toute utilisation hors du
périmètre défini par votre contrat de licence est interdite.

This kit is provided as part of your IA'm Pro license agreement.
Its content is protected by INPI registration no. 5212301 (class 41)
and published under Creative Commons BY-NC 4.0. Any use outside the
scope defined by your license agreement is prohibited.

---

*IA'm — iam-inside.eu*
*Plogoff, Cap Sizun, France*
